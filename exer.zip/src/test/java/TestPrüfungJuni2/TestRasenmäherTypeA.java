/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestPrüfungJuni2;

import PrüfungJuni2.Generation;
import PrüfungJuni2.Messer;
import PrüfungJuni2.RasenmäherTypeA;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 *
 * @author alexi
 */
public class TestRasenmäherTypeA {

    @Test
    public void testGenerationG1() {
        Messer messer = new Messer();
        RasenmäherTypeA rasenmäherTypeA = new RasenmäherTypeA(messer);
        Assertions.assertEquals(Generation.G1, rasenmäherTypeA.getGeneration());
    }

}
