/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestPrüfungJuni2;

import PrüfungJuni2.Generation;
import PrüfungJuni2.Messer;
import PrüfungJuni2.RasenmäherTypeA;
import PrüfungJuni2.RasenmäherTypeB;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 *
 * @author alexi
 */
public class TestRasenmäherTypeB {
    @Test
    public void testGenerationG2() {
        Messer messer = new Messer();
        RasenmäherTypeB rasenmäherTypeB = new RasenmäherTypeB(messer);
        Assertions.assertEquals(Generation.G2,rasenmäherTypeB.getGeneration());}

}

    

