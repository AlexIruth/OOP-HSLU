/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestPrüfungJuni2;

import PrüfungJuni2.Generation;
import PrüfungJuni2.RasenmäherLager;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 * n    
 * @author alexi
 */
public class TestRasenmäherLager {
    
    @Test
    public void testCountG1() {
        RasenmäherLager rasenmäherLager = new RasenmäherLager();
        Assertions.assertEquals(2, rasenmäherLager.getCountRasenmäherGenerations(Generation.G1));
    }
    
    @Test
    public void testCoountG2() {
        RasenmäherLager rasenmäherLager = new RasenmäherLager();
        Assertions.assertEquals(1, rasenmäherLager.getCountRasenmäherGenerations(Generation.G2));
    }
    
    @Test
    public void testCountG3() {
        RasenmäherLager rasenmäherLager = new RasenmäherLager();
        Assertions.assertEquals(0, rasenmäherLager.getCountRasenmäherGenerations(Generation.G3));
    }
    
}
