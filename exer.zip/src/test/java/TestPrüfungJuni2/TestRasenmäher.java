/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestPrüfungJuni2;

import PrüfungJuni2.Messer;
import PrüfungJuni2.Rasenmäher;
import PrüfungJuni2.RasenmäherTypeA;
import nl.jqno.equalsverifier.EqualsVerifier;
import org.junit.jupiter.api.Assertions;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 *
 * @author alexi
 */
public class TestRasenmäher {

    @Test
    public void testKonstruktor() {
        Messer messer = new Messer();
        Rasenmäher rasenmäher = new RasenmäherTypeA(messer);
        Assertions.assertEquals(messer, rasenmäher.getMesser());
        Assertions.assertNotNull(rasenmäher.getAntrieb());

    }

    @Test
    public void testSeriennummer() {
        Messer messer = new Messer();
        Rasenmäher rasenmäher1 = new RasenmäherTypeA(messer);
        Rasenmäher rasenmäher2 = new RasenmäherTypeA(messer);
        Assertions.assertNotNull(rasenmäher1.getSeriennummer());
        Assertions.assertEquals(7, rasenmäher1.getSeriennummer().length());
        Assertions.assertNotEquals(rasenmäher1.getSeriennummer(), rasenmäher2.getSeriennummer());
    }

    @Test
    public void simpleEqualsContract() {
        EqualsVerifier.simple().forClass(Rasenmäher.class).withIgnoredFields("antrieb", "messer", "generation").verify();
    }

    @Test
    public void testCompareLessRasenmäher() {
        Messer messer1 = new Messer();
        Messer messer2 = new Messer();
        Rasenmäher rasenmäher1 = new RasenmäherTypeA(messer1);
        Rasenmäher rasenmäher2 = new RasenmäherTypeA(messer2);
        assertEquals(-1, rasenmäher1.compareTo(rasenmäher2));
    }

    @Test
    public void testCompareGreaterRasenmäher() {
        Messer messer1 = new Messer();
        Messer messer2 = new Messer();
        Rasenmäher rasenmäher1 = new RasenmäherTypeA(messer1);
        Rasenmäher rasenmäher2 = new RasenmäherTypeA(messer2);
        assertEquals(1, rasenmäher2.compareTo(rasenmäher1));

    }

    @Test
    public void testComopareSameRasenmäher() {
        Messer messer1 = new Messer();
        Rasenmäher rasenmäher1 = new RasenmäherTypeA(messer1);
        assertEquals(0, rasenmäher1.compareTo(rasenmäher1));
    }
}
