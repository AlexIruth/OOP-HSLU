/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PrüfungJuni2;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


/**
 *
 * @author alexi
 */
public class TestMesser {

    @Test
    public void testDefaultKonstruktor() {
        Messer messer = new Messer();
        assertEquals(56, messer.getSharpnessInHrc());
    }

    @Test
    public void testKonstruktor() {
        Messer messer = new Messer(33);
        assertEquals(33,messer.getSharpnessInHrc());
    }

}







