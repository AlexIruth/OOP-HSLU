package ch.hslu.sw04.Switchable;


/**
 * Tragen Sie hier eine Beschreibung des Interface Named ein.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */

public interface Named 
{
    void setName(final String name);
    String getName();
}
