package ch.hslu.sw04.Switchable;

public interface CountingSwitchable extends Switchable {

    public long getSwitchCount();
}
