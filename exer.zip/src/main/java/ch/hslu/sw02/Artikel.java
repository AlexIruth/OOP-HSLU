
package ch.hslu.sw02; 

public class Artikel
{
    // Instanzvariablen - ersetzen Sie das folgende Beispiel mit Ihren Variablen
   
    private String produktname;
    private int stueckpreis;
    private int anzahl;
    
    public Artikel(String Produktname,int Stueckpreis,int Anzahl)
    {
        // Instanzvariable initialisieren
        produktname = "unkown";
        stueckpreis = 0;
        anzahl = 0;

    }

    public String getName()
    {
        return "";
    }
    
}
