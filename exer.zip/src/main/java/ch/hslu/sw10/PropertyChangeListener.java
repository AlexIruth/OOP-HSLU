/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ch.hslu.sw10;

import java.beans.PropertyChangeEvent;

/**
 *
 * @author alexi
 */
public interface PropertyChangeListener {

    public void propertyChange(PropertyChangeEvent event);

}
