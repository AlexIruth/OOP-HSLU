/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.hslu.sw03.Temperatur.Semesterwoche3;


public class Max

{

    /**
     *
     * @param a
     * @param b
     * @return
     */
    public static int max(int a, int b)
    { if (a>b)

        {return a; } 

        else

        {return b;}
    }
}   