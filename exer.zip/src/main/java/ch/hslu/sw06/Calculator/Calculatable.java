/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.hslu.sw06.Calculator;

/**
 *
 * @author alexi
 */
public interface Calculatable {
    
public int additon(int i, int j);


    
}

