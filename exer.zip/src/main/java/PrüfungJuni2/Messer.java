/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PrüfungJuni2;

/**
 *
 * @author alexi
 */
public class Messer {

    private float sharpnessInHrc;
    private static final float DEFAULT_SHARPNESS = 56f;

    public Messer(float sharpnessInHrc) {
        this.sharpnessInHrc = sharpnessInHrc;

    }

    public Messer() {

        this.sharpnessInHrc = DEFAULT_SHARPNESS;

    }

    public float getSharpnessInHrc() {
        return this.sharpnessInHrc;

    }

    public void setSharpnessInHrc(float sharpnessInHrc) {

        this.sharpnessInHrc = sharpnessInHrc;

    }

    @Override
    public String toString() {
        return "Messer[sharpnessInHrc=" + this.sharpnessInHrc + "]";
    }
}
