/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PrüfungJuni2;

import java.util.Objects;

/**
 *
 * @author alexi
 */
public abstract class Rasenmäher implements Comparable<Rasenmäher>  {

    private final Antrieb antrieb;
    private Messer messer;
    private final String seriennummer;
    private static int zaehler = 20000;
    protected final Generation generation;

    public Rasenmäher(Messer messer, Generation generation) {
        this.messer = messer;
        this.antrieb = new Antrieb();
        this.seriennummer = "SV" + zaehler;
        this.zaehler++;
        this.generation = generation;
    }

    public Messer getMesser() {

        return this.messer;

    }

    public void setMesser(Messer messer) {
        this.messer = messer;
    }

    public Antrieb getAntrieb() {
        return this.antrieb;
    }

    public String getSeriennummer() {
        return this.seriennummer;
    }

    @Override
    public String toString() {
        return "Rasenmäher[antrieb=" + antrieb.toString() + ";messer=" + messer.toString()
                + ";seriennummer=" + this.seriennummer + ";generation" + generation.getDate();

    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof PrüfungJuni2.Rasenmäher && seriennummer != null) {
            return this.seriennummer.equals(((PrüfungJuni2.Rasenmäher) object).seriennummer);
        } else {
            return seriennummer == null && ((PrüfungJuni2.Rasenmäher) object).seriennummer == null;

        }

    }

    @Override
    public int hashCode() {
        return Objects.hashCode(seriennummer);
    }

    @Override
    public int compareTo(Rasenmäher other) {
        return this.seriennummer.compareTo(other.seriennummer);

    }

    public Generation getGeneration() {
        return this.generation;
    }
}
